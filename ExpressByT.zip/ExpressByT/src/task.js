const express = require("express");

const app =express();

app.get('/',(req,res) =>
{
    res.send("These is main page ");
});

app.get('/content', (req,res) =>
{
    res.send("These is Conent page");
});

app.get('/about' ,(req,res) =>
{
    res.send("These is about page ");
})
app.listen(3000 ,() =>
{
    console.log("Listening port 3000");
});
