const express = require('express');
const app = express();      
const path = require('path');
const hbs =require('hbs');

// To import hbs in file 


//console.log(path.join(__dirname, '../TemplateEngine/templates'));
//const Staticath = path.join(__dirname, '../TemplateEngine/templates');
const templatePath =path.join(__dirname,'../templates');
console.log(templatePath);
app.set('view engine', 'hbs');
app.set('views',templatePath);
app.get('/', (req, res) => {
    res.render('index');
    console.log("reach at these point");
});
app.get('/home', (req, res) => {
    res.send("these Is home page ");
});

app.listen(3000, () => {
    console.log('Listening port 3000 ');
});