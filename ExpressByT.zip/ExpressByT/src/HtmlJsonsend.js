const  express = require('express');

const  add =express();

add.get('/',(req,res) => {
   // res.send("These is original data ");
    res.send("<h1>These JSON data in the Form of HTML <h1>");

});
add.get('/json',(req,res) =>
{
    res.json ([
    {
        Name :"Sahil",
        age :24,
        Surname:"Mujawar",
    },
    {
        Name :"aniket",
        age :24,
        Surname:"jadhav" 
    },
    {
        Name :"new",
        age :24,
        Surname:"War    "
    }
]);
});
add.listen(3000, ()=>{
    console.log("Listening port no 3000");
});