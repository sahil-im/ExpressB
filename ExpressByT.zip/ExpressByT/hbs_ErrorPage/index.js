const express = require('express');
const app = express();
const path =require('path');
const port =8000;
 tempv=(path.join(__dirname,'../ExpressT/tempviews'));
app.set("view engine" ,"hbs");
app.set('views',tempv)
app.get('/',(req,res) =>
{
    res.render('Demo');
})
app.get('/Friends',(req,res) =>
{
    console.log(req.query.name);     
    res.send(`These is friends`);
});
app.get('/Family',(req,res) =>
{
    res.send("These is Family page ");
});

app.get('*', (req,res) =>
{
    res.render('404page');
})

app.listen(8000, () =>
{
    console.log(`listenningport no ${port}`);
})
